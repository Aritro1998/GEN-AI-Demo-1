# This script creates a SQLite database named 'databse' and adds a 'user' table.
import sqlite3

conn = sqlite3.connect('databse.db')
cursor = conn.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    fisrtname TEXT,
    lastname TEXT,
    created_by TEXT,
    created_on TEXT,
    modified_by TEXT,
    modified_on TEXT,
    is_locked INTEGER DEFAULT 0
)
''')

conn.commit()
conn.close()
