# API Endpoints (The Entry Point)
from fastapi import FastAPI, HTTPException, Depends, Request, Header, status, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from repository.user_repository import UserRepository
from models import UserCreate, UserLogin, ChangePwd
from fastapi.middleware.cors import CORSMiddleware
from auth import AuthManager
import json, os
from fastapi_socketio import SocketManager

CONFIG_PATH = os.path.join(os.path.dirname(__file__), 'config.json')

app = FastAPI()
user_repo = UserRepository()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

if os.path.exists(CONFIG_PATH):
    with open(CONFIG_PATH, 'r') as f:
        config = json.load(f)
    JWT_SECRET = config.get('JWT_SECRET', 'secret-key')
    JWT_ALGORITHM = config.get('JWT_ALGORITHM', 'HS256')
else:
    JWT_SECRET = 'secret-key'
    JWT_ALGORITHM = 'HS256'

auth_manager = AuthManager(JWT_SECRET, JWT_ALGORITHM)

def authenticate_token(x_access_token: str = Header(...)):
    try:
        payload = auth_manager.decode_jwt(x_access_token)
        return payload
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")

@app.middleware("http")
async def log_requests(request: Request, call_next):
    # Example: Log each request
    print(f"Incoming request: {request.method} {request.url}")
    response = await call_next(request)
    print(f"Response status: {response.status_code}")
    return response

class UserCreate(BaseModel):
    username: str
    password: str
    fisrtname: str
    lastname: str
    created_by: str
    user_role: str

@app.post('/create')
def create_user(user: UserCreate, x_access_token: str = Header(...)):
    authenticate_token(x_access_token)
    user_repo.create_user(user.username, user.password, user.fisrtname, user.lastname, user.created_by, user.user_role)
    return {"message": "User created"}

@app.delete('/delete/{username}')
def delete_user(username: str, x_access_token: str = Header(...)):
    authenticate_token(x_access_token)
    user_repo.delete_user(username)
    return {"message": "User deleted"}

@app.post('/unlock/{username}')
def unlock_user(username: str, x_access_token: str = Header(...)):
    authenticate_token(x_access_token)
    user_repo.unlock_user(username)
    return {"message": "User unlocked"}

@app.post('/changepwd')
def change_password(data: ChangePwd, x_access_token: str = Header(...)):
    authenticate_token(x_access_token)
    user_repo.change_password(data.username, data.new_password)
    return {"message": "Password changed"}

@app.post('/login')
def login(user: UserLogin):
    token, role = user_repo.login(user.username, user.password)
    if not token:
        raise HTTPException(status_code=401, detail=role)
    response = {"message": "Login successful", "username": user.username, "role": role}
    headers = {"x-access-token": token}
    return JSONResponse(content=response, headers=headers)

@app.get('/users')
def get_all_users(x_access_token: str = Header(...)):
    authenticate_token(x_access_token)
    users = user_repo.get_all_users()
    return {"users": users}

