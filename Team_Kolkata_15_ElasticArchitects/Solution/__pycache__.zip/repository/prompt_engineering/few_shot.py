# Few Shot Logic
