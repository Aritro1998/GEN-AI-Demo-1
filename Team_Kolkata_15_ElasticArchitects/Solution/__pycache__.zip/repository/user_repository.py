# Handles user authentication and management logic for SQLite DB
import sqlite3
import jwt
import datetime
import json
import os
from auth import AuthManager
from repository.llm.base import ModelCapability, get_chat_llm

# --- Config Loading ---
CONFIG_PATH = os.path.join(os.path.dirname(__file__), '../config.json')

if os.path.exists(CONFIG_PATH):
    with open(CONFIG_PATH, 'r') as f:
        config = json.load(f)
    DB_PATH = config.get('DB_PATH', 'app.db')
    JWT_SECRET = config.get('JWT_SECRET', 'secret-key')
    JWT_ALGORITHM = config.get('JWT_ALGORITHM', 'HS256')
else:
    DB_PATH = 'app.db'
    JWT_SECRET = 'secret-key'
    JWT_ALGORITHM = 'HS256'

auth_manager = AuthManager(JWT_SECRET, JWT_ALGORITHM)

class UserRepository:
    def __init__(self):
        self.db_path = DB_PATH

    def get_user(self, username):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM user WHERE username=?", (username,))
        user = cursor.fetchone()
        conn.close()
        return user

    def create_user(self, username, password, fisrtname, lastname, created_by, user_role):
        hashed_pwd = auth_manager.hash_password(password)
        now = datetime.datetime.now().isoformat()
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO user (username, password, fisrtname, lastname, created_by, created_on, is_locked, user_role)
            VALUES (?, ?, ?, ?, ?, ?, 0, ?)
        """, (username, hashed_pwd, fisrtname, lastname, created_by, now, user_role))
        conn.commit()
        conn.close()

    def delete_user(self, username):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM user WHERE username=?", (username,))
        conn.commit()
        conn.close()

    def unlock_user(self, username):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE user SET is_locked=0 WHERE username=?", (username,))
        conn.commit()
        conn.close()

    def change_password(self, username, new_password):
        hashed_pwd = auth_manager.hash_password(new_password)
        now = datetime.datetime.now().isoformat()
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE user SET password=?, modified_on=? WHERE username=?
        """, (hashed_pwd, now, username))
        conn.commit()
        conn.close()

    def login(self, username, password):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id, password, is_locked, user_role FROM user WHERE username=?", (username,))
        user = cursor.fetchone()
        reasoning_llm = get_chat_llm(ModelCapability.MODERATE)
        response = reasoning_llm.invoke("hii")
        print(response)
        if not user:
            conn.close()
            return None, 'User not found'
            
        user_id, stored_hash, is_locked, user_role = user
        
        if is_locked:
            conn.close()
            return None, 'Account is locked'
            
        cursor.execute("SELECT failed_attempts FROM user WHERE username=?", (username,))
        fa_row = cursor.fetchone()
        failed_attempts = fa_row[0] if fa_row else 0
        
        if not auth_manager.verify_password(password, stored_hash):
            failed_attempts += 1
            if failed_attempts >= 3:
                cursor.execute("UPDATE user SET is_locked=1, failed_attempts=? WHERE username=?", (failed_attempts, username))
                conn.commit()
                conn.close()
                return None, 'Account locked due to too many failed attempts'
            else:
                cursor.execute("UPDATE user SET failed_attempts=? WHERE username=?", (failed_attempts, username))
                conn.commit()
                conn.close()
                return None, f'Wrong password. {3 - failed_attempts} attempts left.'
        
        # Reset failed_attempts on successful login
        cursor.execute("UPDATE user SET failed_attempts=0 WHERE username=?", (username,))
        conn.commit()
        conn.close()
        
        token = auth_manager.create_jwt(user_id, username, user_role, exp_minutes=10)
        return token, user_role

    def get_all_users(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, fisrtname, lastname, created_by, created_on, modified_by, modified_on, is_locked, user_role FROM user")
        users = cursor.fetchall()
        conn.close()
        # Return as list of dicts
        return [
            {
                "id": u[0],
                "username": u[1],
                "fisrtname": u[2],
                "lastname": u[3],
                "created_by": u[4],
                "created_on": u[5],
                "modified_by": u[6],
                "modified_on": u[7],
                "is_locked": u[8],
                "user_role": u[9]
            } for u in users
        ]