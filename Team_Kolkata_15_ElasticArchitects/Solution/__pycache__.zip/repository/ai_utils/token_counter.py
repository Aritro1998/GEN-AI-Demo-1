# Token Counter
