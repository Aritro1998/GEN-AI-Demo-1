# DB Tables & Pydantic Schemas
from pydantic import BaseModel

class UserCreate(BaseModel):
    username: str
    password: str
    fisrtname: str
    lastname: str
    created_by: str

class UserLogin(BaseModel):
    username: str
    password: str

class ChangePwd(BaseModel):
    username: str
    new_password: str