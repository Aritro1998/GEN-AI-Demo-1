# Authentication Logic
import jwt
import datetime
from passlib.hash import argon2

class AuthManager:
    def __init__(self, secret, algorithm):
        self.secret = secret
        self.algorithm = algorithm

    def hash_password(self, password):
        return argon2.hash(password)

    def verify_password(self, password, hashed):
        try:
            return argon2.verify(password, hashed)
        except Exception:
            return False

    def create_jwt(self, user_id, username, user_role, exp_minutes=10):
        payload = {
            'user_id': user_id,
            'username': username,
            'role': user_role,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=exp_minutes)
        }
        return jwt.encode(payload, self.secret, algorithm=self.algorithm)

    def decode_jwt(self, token):
        return jwt.decode(token, self.secret, algorithms=[self.algorithm])
